const apiKey = "440186c8dbdfd3fbda060d5d7685f9b9"; // Replace with your OpenWeatherMap API key

function getWeather() {
  const city = document.getElementById("cityInput").value;
  const resultDiv = document.getElementById("weatherResult");

  if (city === "") {
    resultDiv.innerHTML = "<p>Please enter a city name.</p>";
    return;
  }

  const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

  fetch(url)
    .then((response) => {
      if (!response.ok) {
        throw new Error("City not found");
      }
      return response.json();
    })
    .then((data) => {
      const temp = data.main.temp;
      const humidity = data.main.humidity;
      const condition = data.weather[0].description;
      const icon = `https://openweathermap.org/img/wn/${data.weather[0].icon}.png`;

      resultDiv.innerHTML = `
        <h2>${data.name}</h2>
        <img src="${icon}" alt="weather icon" />
        <p>Temperature: ${temp} °C</p>
        <p>Humidity: ${humidity}%</p>
        <p>Condition: ${condition}</p>
      `;
    })
    .catch((error) => {
      resultDiv.innerHTML = `<p>${error.message}</p>`;
    });
}